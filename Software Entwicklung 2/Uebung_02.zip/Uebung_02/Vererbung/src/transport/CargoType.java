package transport;

public enum CargoType {
    LIQUID, SOLID
}