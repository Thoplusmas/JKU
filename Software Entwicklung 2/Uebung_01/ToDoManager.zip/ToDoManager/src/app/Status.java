package app;

public enum Status {
    OPEN, DONE,
}
