package pricing;

public enum DiscountRate {
    LOW, MEDIUM, HIGH
}